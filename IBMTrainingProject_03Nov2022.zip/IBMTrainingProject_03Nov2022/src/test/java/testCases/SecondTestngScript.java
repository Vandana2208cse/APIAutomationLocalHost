package testCases;

import org.testng.annotations.Test;

public class SecondTestngScript {

	@Test
	
	public void printName() {
		System.out.println("VandanaSingh");
	}
}
