package ProjectWork;

public class ProjectPOJOClass {
	private String phase;
	 private String module;
	 private String id;
	public String getPhase() {
		return phase;
	}
	public void setPhase(String phase) {
		this.phase = phase;
	}
	public String getModule() {
		return module;
	}
	public void setModule(String module) {
		this.module = module;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}

	// converting object data back to string 
	  public static void ToString(ProjectPOJOClass obj)
     
     {
         System.out.println(obj.getPhase());
         System.out.println(obj.getModule());
         System.out.println(obj.getId());
         
     }
	
}
