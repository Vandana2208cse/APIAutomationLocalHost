package ProjectWork;

import java.io.File;

import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.response.Response;

public class ReadFromJsonFile {

	@Test(enabled = true)
    public void POST() {
        
        RestAssured.baseURI = "http://localhost:3000";
        RestAssured.given().log().all().body(new File("./Data.json"))
                // Giving header details are important
                .header("Content-Type", "application/json").when().post("/project");
        Response resp2 = RestAssured.get("http://localhost:3000/project");
        System.out.println(resp2.asString());
    }
}
