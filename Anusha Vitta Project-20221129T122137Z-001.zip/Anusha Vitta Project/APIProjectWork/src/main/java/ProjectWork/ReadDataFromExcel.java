package ProjectWork;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;

import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class ReadDataFromExcel {
	public static void main(String[] args) throws IOException {
        String pathofExcelSheet = "C:\\Users\\08408C744\\Desktop\\TestAPI.xlsx";
        File file = new File(pathofExcelSheet);
        FileInputStream fis = new FileInputStream(file);
        
        XSSFWorkbook wb = new XSSFWorkbook(fis);
        XSSFSheet sheetOfInterest = wb.getSheet("Sheet1");
        XSSFRow rowOfInterest = sheetOfInterest.getRow(1);
        System.out.println(rowOfInterest.getCell(1).getStringCellValue().toString());
    }
}
