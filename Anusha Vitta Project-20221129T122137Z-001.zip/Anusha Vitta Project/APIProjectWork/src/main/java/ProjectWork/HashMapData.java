package ProjectWork;

import java.util.HashMap;

public class HashMapData {

public static void main(String[] args) {
        
        HashMap<String, String> hm = new HashMap<String, String>();
        hm.put("id", "6");
        hm.put("phase", "API5");
        hm.put("module", "Fifth");
        
        System.out.println(hm);
        System.out.println(hm.get("id"));
        
}      
}
