package ProjectWork;

import java.util.HashMap;

import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.response.Response;

public class ReadDataFromHashMap {
	
	public class DataReadingFromHashMap {

		@Test(enabled = true)
	    public void POST() {
	        HashMap<String, String> hm = new HashMap<String, String>();
	        hm.put("phase", "API3");
	        hm.put("module", "third");
	        hm.put("id", "5");
	        RestAssured.baseURI = "http://localhost:3000";
	        RestAssured.given().log().all().body(hm)
	                // Giving header details are important
	                .header("Content-Type", "application/json").when().post("/project");
	        Response resp2 = RestAssured.get("http://localhost:3000/project/5");
	        System.out.println(resp2.asString());
	    }
	}
}
