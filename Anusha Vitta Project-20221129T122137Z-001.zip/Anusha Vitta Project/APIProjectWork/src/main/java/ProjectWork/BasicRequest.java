package ProjectWork;

import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.response.Response;

public class BasicRequest {
@Test (enabled = false)
	
	public void GetMethod() {
        // First fetch the response in the response container
        Response resp = RestAssured.get("http://localhost:3000/project");
        // change the response in string and print it .
        System.out.println(resp.asString());
    }
	
		@Test(enabled = false)
    public void POST() {
        // Basic details which are given to us Should be kept at global level
        // Make sure that thereis no space in the URL
        RestAssured.baseURI = "http://localhost:3000";
        String Body = "{\r\n"
        		+ "      \"phase\": \"API3\",\r\n"
        		+ "      \"module\": \"first3\"\r\n"
        		+ "      \r\n"
        		+ "    }";
        
        // First fetch the response in the response container
        RestAssured
        .given()
        .log().all()
        .body(Body)
                // Giving header details are important
                .header("Content-Type", "application/json")
                .post("/project");
        Response resp2 = RestAssured.get("http://localhost:3000/project");
        System.out.println(resp2.asString());
    }

		@Test(enabled = false )
	    public void Delete() {
	        // First fetch the response in the response container
	        Response resp = RestAssured.when()
	                .delete("http://localhost:3000/project/5");
	        // Extract the response code and response message and print it
	        System.out.println(resp.statusCode());
	        System.out.println(resp.statusLine());
	    }
	
		@Test(enabled = false)
	    public void PUT() {
	        // For PUT request , we always have to provide the ID for which you wants to do
	        // the changes
	        String Body = " {\r\n"
	        		+ "        \"phase\": \"FirstAPI\",\r\n"
	        		+ "        \"module\": \"first one to test\"\r\n"
	        		+ "}";
	        // First fetch the response in the response container
	        Response resp = RestAssured.given().header("Content-Type", "application/json").body(Body).when()
	                .put("http://localhost:3000/project/1");
	        // Extract the response code and response message and print it
	        System.out.println("********************************************************************");
	        System.out.println("The status Code is :" + resp.statusCode());
	        System.out.println("The status response line s :" + resp.statusLine());
	        System.out.println("********************************************************************");
	        Response resp2 = RestAssured.get("http://localhost:3000/project/1");
	        System.out.println(resp2.asString());
	    }
	
		@Test(enabled = true )
	    public void PATCH() {
	        // For PUT request , we always have to provide the ID fr which you wants to do
	        // the changes
	        String Body = " {\r\n"
	        		     		+ "        \"module\": \"firstone\"\r\n"
	        		+ "}";
	        // First fetch the response in the response container
	        Response resp = RestAssured.given().header("Content-Type", "application/json").body(Body).when()
	                .patch("http://localhost:3000/project/1");
	        // Extract the response code and response message and print it
	        System.out.println("********************************************************************");
	        System.out.println("The status Code is :" + resp.statusCode());
	        System.out.println("The status response line s :" + resp.statusLine());
	        System.out.println("********************************************************************");
	        Response resp2 = RestAssured.get("http://localhost:3000/project/1");
	        System.out.println(resp2.asString());
	        //assertEquals(200, resp.statusCode());
	        //assertNotNull(resp.statusCode());
	    }
		

}
