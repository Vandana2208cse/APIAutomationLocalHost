package ProjectWork;

import org.testng.annotations.Test;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import io.restassured.RestAssured;
import io.restassured.response.Response;

public class ReadDataFromPOJOClass {
	@Test(enabled = true)
    public void POST() throws JsonProcessingException {
        RestAssured.baseURI = "http://localhost:3000";
        // Reading the data from POJO Class for the payload details
        ProjectPOJOClass objPojo = new ProjectPOJOClass();
        objPojo.setModule("Regression");
        objPojo.setPhase("APITestPojo");
                
        // Object Mapper
        ObjectMapper mapper = new ObjectMapper();
        String jsonBodyData = mapper.writeValueAsString(objPojo);
        
        RestAssured.given().log().all().body(jsonBodyData)
                // Giving header details are important
                .header("Content-Type", "application/json").when().post("/project");
        Response resp2 = RestAssured.get("http://localhost:3000/project");
        System.out.println(resp2.asString());

	//Deserializaion code
        ProjectPOJOClass objPojo2 =RestAssured.given().get("http://localhost:3000/project/3")
            .as(ProjectPOJOClass.class);
    
        ProjectPOJOClass.ToString(objPojo2);
}	
}
